<?php
require_once __DIR__ . '/bd.php';
$bd = new BD();

$id = null;
if (isset($_GET['id'])) {
    $id = filter_var($_GET['id'], FILTER_VALIDATE_INT);
    if ($id === false || $id < 1) {
        http_response_code(400);
        exit('El identificador del producto no es válido.');
    }
}

$producto = $id === null ? null : $bd->findById($id);
if ($id !== null && $producto === null) {
    http_response_code(404);
    exit('No se encontró el producto.');
}

$nombre = $producto?->getNombre() ?? '';
$precio = $producto === null ? '' : number_format($producto->getPrecio(), 2, '.', '');
$cantidad = $producto?->getCantidad() ?? 0;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim((string) ($_POST['nombre'] ?? ''));
    $precio = trim((string) ($_POST['precio'] ?? ''));
    $cantidadEntrada = trim((string) ($_POST['cantidad'] ?? ''));
    $cantidadValidada = filter_var($cantidadEntrada, FILTER_VALIDATE_INT);

    if ($nombre === '' || preg_match('/^.{1,100}$/us', $nombre) !== 1) {
        $error = 'El nombre es obligatorio y no puede superar los 100 caracteres.';
    } elseif (preg_match('/^\d{1,8}(?:\.\d{1,2})?$/', $precio) !== 1) {
        $error = 'El precio debe ser un número positivo con hasta dos decimales.';
    } elseif ($cantidadValidada === false || $cantidadValidada < 0 || $cantidadValidada > 2147483647) {
        $error = 'La cantidad debe ser un entero entre cero y 2147483647.';
    } else {
        $bd->guardar(new Producto(
            $id,
            $nombre,
            (float) $precio,
            $cantidadValidada
        ));
        header('Location: index.php');
        exit;
    }

    $cantidad = $cantidadEntrada;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title><?= $id === null ? 'Nuevo producto' : 'Editar producto' ?></title>
</head>
<body>
  <h1><?= $id === null ? 'Nuevo producto' : 'Editar producto' ?></h1>

  <?php if ($error !== ''): ?>
    <p role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
  <?php endif; ?>

  <form method="post">
    <p>
      <label for="nombre">Nombre</label>
      <input id="nombre" name="nombre" type="text" maxlength="100" required
             value="<?= htmlspecialchars($nombre, ENT_QUOTES, 'UTF-8') ?>">
    </p>
    <p>
      <label for="precio">Precio (€)</label>
      <input id="precio" name="precio" type="number" min="0" max="99999999.99"
             step="0.01" required
             value="<?= htmlspecialchars((string) $precio, ENT_QUOTES, 'UTF-8') ?>">
    </p>
    <p>
      <label for="cantidad">Cantidad</label>
      <input id="cantidad" name="cantidad" type="number" min="0" max="2147483647" step="1" required
             value="<?= htmlspecialchars((string) $cantidad, ENT_QUOTES, 'UTF-8') ?>">
    </p>
    <button type="submit">Guardar</button>
    <a href="index.php">Cancelar</a>
  </form>
</body>
</html>