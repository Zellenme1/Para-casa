<?php
require_once __DIR__ . '/bd.php';
$bd = new BD();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    exit('Método no permitido.');
}

$id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
if ($id === false || $id === null || $id < 1) {
    http_response_code(400);
    exit('El identificador del producto no es válido.');
}

$bd->borrar($id);
header('Location: index.php');
exit;